```python
#未进行数据清理
import pandas as pd
# load the training dataset
building_data = pd.read_csv('data/real_estate.csv')
building_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>transaction_date</th>
      <th>house_age</th>
      <th>transit_distance</th>
      <th>local_convenience_stores</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>price_per_unit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012.917</td>
      <td>32.0</td>
      <td>84.87882</td>
      <td>10</td>
      <td>24.98298</td>
      <td>121.54024</td>
      <td>37.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2012.917</td>
      <td>19.5</td>
      <td>306.59470</td>
      <td>9</td>
      <td>24.98034</td>
      <td>121.53951</td>
      <td>42.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2013.583</td>
      <td>13.3</td>
      <td>561.98450</td>
      <td>5</td>
      <td>24.98746</td>
      <td>121.54391</td>
      <td>47.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2013.500</td>
      <td>13.3</td>
      <td>561.98450</td>
      <td>5</td>
      <td>24.98746</td>
      <td>121.54391</td>
      <td>54.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012.833</td>
      <td>5.0</td>
      <td>390.56840</td>
      <td>5</td>
      <td>24.97937</td>
      <td>121.54245</td>
      <td>43.1</td>
    </tr>
  </tbody>
</table>
</div>




```python
numeric_features = ['house_age',"transit_distance", 'local_convenience_stores', 'latitude',"longitude"]
building_data[numeric_features + ['price_per_unit']].describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>house_age</th>
      <th>transit_distance</th>
      <th>local_convenience_stores</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>price_per_unit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>414.000000</td>
      <td>414.000000</td>
      <td>414.000000</td>
      <td>414.000000</td>
      <td>414.000000</td>
      <td>414.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>17.712560</td>
      <td>1083.885689</td>
      <td>4.094203</td>
      <td>24.969030</td>
      <td>121.533361</td>
      <td>37.980193</td>
    </tr>
    <tr>
      <th>std</th>
      <td>11.392485</td>
      <td>1262.109595</td>
      <td>2.945562</td>
      <td>0.012410</td>
      <td>0.015347</td>
      <td>13.606488</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>23.382840</td>
      <td>0.000000</td>
      <td>24.932070</td>
      <td>121.473530</td>
      <td>7.600000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>9.025000</td>
      <td>289.324800</td>
      <td>1.000000</td>
      <td>24.963000</td>
      <td>121.528085</td>
      <td>27.700000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>16.100000</td>
      <td>492.231300</td>
      <td>4.000000</td>
      <td>24.971100</td>
      <td>121.538630</td>
      <td>38.450000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>28.150000</td>
      <td>1454.279000</td>
      <td>6.000000</td>
      <td>24.977455</td>
      <td>121.543305</td>
      <td>46.600000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>43.800000</td>
      <td>6488.021000</td>
      <td>10.000000</td>
      <td>25.014590</td>
      <td>121.566270</td>
      <td>117.500000</td>
    </tr>
  </tbody>
</table>
</div>




```python
import pandas as pd
import matplotlib.pyplot as plt
# 这将确保在Jupyter笔记本中内联显示
%matplotlib inline
# 获取标签栏
label = building_data['price_per_unit']


# 为2个子类别（2行，1列）创建一个图

fig, ax = plt.subplots(2, 1, figsize = (9,12))


# 绘制柱状图  

ax[0].hist(label, bins=100)

ax[0].set_ylabel('Frequency')


# 添加平均数、中位数和模式的线条

ax[0].axvline(label.mean(), color='magenta', linestyle='dashed', linewidth=2)

ax[0].axvline(label.median(), color='cyan', linestyle='dashed', linewidth=2)

# 绘制boxplot   

ax[1].boxplot(label, vert=False)

ax[1].set_xlabel('price_per_unit')


# 为图标添加一个标题

fig.suptitle('Rental Distribution')


# 展示

fig.show()

```


![png](output_2_0.png)



```python
for col in numeric_features:
    fig = plt.figure(figsize=(9, 6))
    ax = fig.gca()
    feature = building_data[col]
    feature.hist(bins=100, ax = ax) 
    ax.axvline(feature.mean(), color='cyan', linestyle='dashed', linewidth=2)
    ax.axvline(feature.median(), color='cyan', linestyle='dashed', linewidth=2)
    ax.set_title(col)
plt.show()




```


![png](output_3_0.png)



![png](output_3_1.png)



![png](output_3_2.png)



![png](output_3_3.png)



![png](output_3_4.png)



```python
#显示每个类别的离散值数量
import numpy as np
# plot a bar plot for each categorical feature count
categorical_features = ['house_age','local_convenience_stores', 'latitude',"longitude","transit_distance"]
for col in categorical_features:
    counts = building_data[col].value_counts().sort_index()
    fig = plt.figure(figsize=(9, 6))
    ax = fig.gca()
    counts.plot.bar(ax = ax, color='steelblue')

    ax.set_title(col + ' counts')

    ax.set_xlabel(col) 

    ax.set_ylabel("Frequency")

plt.show()

```


![png](output_4_0.png)



![png](output_4_1.png)



![png](output_4_2.png)



![png](output_4_3.png)



![png](output_4_4.png)



```python
#从上述类别分散数据图中大致可以看出
#transit-distance，latitude,longitude大体上呈均匀分布
#但出现个别值过高情况，可能是因为数据中存在异常值
#其中house-age，local-convenience-stores例外
```


```python
for col in numeric_features:
    fig = plt.figure(figsize=(9, 6))
    ax = fig.gca()
    feature = building_data[col]
    label = building_data['price_per_unit']
    correlation = feature.corr(label)
    plt.scatter(x=feature, y=label)
    plt.xlabel(col)
    plt.ylabel('Building Per Price')

    ax.set_title('price_per_unit vs ' + col + '- correlation: ' + str(correlation))

plt.show()
```


![png](output_6_0.png)



![png](output_6_1.png)



![png](output_6_2.png)



![png](output_6_3.png)



![png](output_6_4.png)



```python
#从散点图的分布中可以看出house-age与price_per_unit呈现微弱的负相关关系
#local-convenience-storeslatitude，longitude与price_per_unit超过0.5，呈现一种正相关关系
```


```python
#训练回归模型#
```


```python
X, y = building_data[[ "transit_distance", 'local_convenience_stores', 'latitude',"house_age"]].values, building_data['price_per_unit'].values
print('Features:',X[:10], '\nLabels:', y[:10], sep='\n')
#分割数据（随机）
from sklearn.model_selection import train_test_split

# Split data 70%-30% into training set and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=0)

print ('Training Set: %d rows\nTest Set: %d rows' % (X_train.shape[0], X_test.shape[0]))
```

    Features:
    [[  84.87882   10.        24.98298   32.     ]
     [ 306.5947     9.        24.98034   19.5    ]
     [ 561.9845     5.        24.98746   13.3    ]
     [ 561.9845     5.        24.98746   13.3    ]
     [ 390.5684     5.        24.97937    5.     ]
     [2175.03       3.        24.96305    7.1    ]
     [ 623.4731     7.        24.97933   34.5    ]
     [ 287.6025     6.        24.98042   20.3    ]
     [5512.038      1.        24.95095   31.7    ]
     [1783.18       3.        24.96731   17.9    ]]
    
    Labels:
    [37.9 42.2 47.3 54.8 43.1 32.1 40.3 46.7 18.8 22.1]
    Training Set: 289 rows
    Test Set: 125 rows



```python
#使用LinearRegression estimators来训练
from sklearn.linear_model import LinearRegression

# 在训练集上拟合一个线性回归模型
model = LinearRegression().fit(X_train, y_train)
print (model)

import matplotlib.pyplot as plt

%matplotlib inline

plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title('Daily Bike Share Predictions')
# overlay the regression line
z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()

#评估模型
from sklearn.metrics import mean_squared_error, r2_score

mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)

rmse = np.sqrt(mse)
print("RMSE:", rmse)

r2 = r2_score(y_test, predictions)
print("R2:", r2)
```

    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)



![png](output_10_1.png)


    MSE: 67.51024638272517
    RMSE: 8.216461913909487
    R2: 0.6038694218568061



```python
#Lasso算法
from sklearn.linear_model import Lasso

# 在训练集上拟合Lasso模型
model = Lasso().fit(X_train, y_train)
print (model, "\n")

# 使用测试数据评估模型
predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)
rmse = np.sqrt(mse)
print("RMSE:", rmse)
r2 = r2_score(y_test, predictions)
print("R2:", r2)

# 绘制预测与实际的对比图
plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title('Daily Bike Share Predictions')
# 叠加回归线
z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()
```

    Lasso(alpha=1.0, copy_X=True, fit_intercept=True, max_iter=1000,
          normalize=False, positive=False, precompute=False, random_state=None,
          selection='cyclic', tol=0.0001, warm_start=False) 
    
    MSE: 84.78047628124169
    RMSE: 9.20763141536637
    R2: 0.5025327134173033



![png](output_11_1.png)



```python
#决策树算法
from sklearn.tree import DecisionTreeRegressor
from sklearn.tree import export_text

# 训练
model = DecisionTreeRegressor().fit(X_train, y_train)
print (model, "\n")

# 可视化树模型
tree = export_text(model)
print(tree)

#评估
predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)
rmse = np.sqrt(mse)
print("RMSE:", rmse)
r2 = r2_score(y_test, predictions)
print("R2:", r2)


plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title('Daily Bike Share Predictions')

z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()
```

    DecisionTreeRegressor(criterion='mse', max_depth=None, max_features=None,
                          max_leaf_nodes=None, min_impurity_decrease=0.0,
                          min_impurity_split=None, min_samples_leaf=1,
                          min_samples_split=2, min_weight_fraction_leaf=0.0,
                          presort=False, random_state=None, splitter='best') 
    
    |--- feature_0 <= 826.83
    |   |--- feature_3 <= 11.70
    |   |   |--- feature_2 <= 24.97
    |   |   |   |--- feature_0 <= 130.53
    |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |--- feature_0 <= 53.07
    |   |   |   |   |   |   |--- feature_3 <= 3.70
    |   |   |   |   |   |   |   |--- value: [57.80]
    |   |   |   |   |   |   |--- feature_3 >  3.70
    |   |   |   |   |   |   |   |--- value: [56.80]
    |   |   |   |   |   |--- feature_0 >  53.07
    |   |   |   |   |   |   |--- feature_3 <= 3.45
    |   |   |   |   |   |   |   |--- value: [54.40]
    |   |   |   |   |   |   |--- feature_3 >  3.45
    |   |   |   |   |   |   |   |--- value: [53.50]
    |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |--- feature_3 <= 8.40
    |   |   |   |   |   |   |--- feature_3 <= 7.90
    |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |--- value: [42.70]
    |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |--- value: [48.70]
    |   |   |   |   |   |   |--- feature_3 >  7.90
    |   |   |   |   |   |   |   |--- feature_3 <= 8.20
    |   |   |   |   |   |   |   |   |--- feature_3 <= 8.05
    |   |   |   |   |   |   |   |   |   |--- value: [51.80]
    |   |   |   |   |   |   |   |   |--- feature_3 >  8.05
    |   |   |   |   |   |   |   |   |   |--- value: [52.05]
    |   |   |   |   |   |   |   |--- feature_3 >  8.20
    |   |   |   |   |   |   |   |   |--- value: [42.80]
    |   |   |   |   |   |--- feature_3 >  8.40
    |   |   |   |   |   |   |--- value: [56.15]
    |   |   |   |--- feature_0 >  130.53
    |   |   |   |   |--- feature_3 <= 1.50
    |   |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |   |--- value: [44.85]
    |   |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |   |--- feature_3 <= 1.05
    |   |   |   |   |   |   |   |--- feature_1 <= 3.00
    |   |   |   |   |   |   |   |   |--- value: [48.85]
    |   |   |   |   |   |   |   |--- feature_1 >  3.00
    |   |   |   |   |   |   |   |   |--- feature_3 <= 0.50
    |   |   |   |   |   |   |   |   |   |--- value: [50.80]
    |   |   |   |   |   |   |   |   |--- feature_3 >  0.50
    |   |   |   |   |   |   |   |   |   |--- value: [50.70]
    |   |   |   |   |   |   |--- feature_3 >  1.05
    |   |   |   |   |   |   |   |--- value: [47.57]
    |   |   |   |   |--- feature_3 >  1.50
    |   |   |   |   |   |--- feature_1 <= 5.50
    |   |   |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |   |   |--- value: [33.60]
    |   |   |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |   |   |--- value: [36.90]
    |   |   |   |   |   |--- feature_1 >  5.50
    |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |--- feature_3 <= 3.15
    |   |   |   |   |   |   |   |   |--- feature_0 <= 381.15
    |   |   |   |   |   |   |   |   |   |--- value: [45.40]
    |   |   |   |   |   |   |   |   |--- feature_0 >  381.15
    |   |   |   |   |   |   |   |   |   |--- value: [47.70]
    |   |   |   |   |   |   |   |--- feature_3 >  3.15
    |   |   |   |   |   |   |   |   |--- feature_1 <= 7.00
    |   |   |   |   |   |   |   |   |   |--- value: [41.60]
    |   |   |   |   |   |   |   |   |--- feature_1 >  7.00
    |   |   |   |   |   |   |   |   |   |--- value: [43.20]
    |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |--- value: [40.50]
    |   |   |--- feature_2 >  24.97
    |   |   |   |--- feature_0 <= 311.49
    |   |   |   |   |--- feature_3 <= 10.45
    |   |   |   |   |   |--- feature_0 <= 286.09
    |   |   |   |   |   |   |--- feature_0 <= 266.84
    |   |   |   |   |   |   |   |--- feature_3 <= 7.30
    |   |   |   |   |   |   |   |   |--- feature_3 <= 5.60
    |   |   |   |   |   |   |   |   |   |--- value: [63.20]
    |   |   |   |   |   |   |   |   |--- feature_3 >  5.60
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 6.05
    |   |   |   |   |   |   |   |   |   |   |--- value: [54.50]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  6.05
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 6.35
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  6.35
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |--- feature_3 >  7.30
    |   |   |   |   |   |   |   |   |--- value: [47.30]
    |   |   |   |   |   |   |--- feature_0 >  266.84
    |   |   |   |   |   |   |   |--- feature_3 <= 5.05
    |   |   |   |   |   |   |   |   |--- value: [47.85]
    |   |   |   |   |   |   |   |--- feature_3 >  5.05
    |   |   |   |   |   |   |   |   |--- value: [47.90]
    |   |   |   |   |   |--- feature_0 >  286.09
    |   |   |   |   |   |   |--- value: [69.54]
    |   |   |   |   |--- feature_3 >  10.45
    |   |   |   |   |   |--- feature_2 <= 24.98
    |   |   |   |   |   |   |--- value: [117.50]
    |   |   |   |   |   |--- feature_2 >  24.98
    |   |   |   |   |   |   |--- value: [55.90]
    |   |   |   |--- feature_0 >  311.49
    |   |   |   |   |--- feature_0 <= 645.41
    |   |   |   |   |   |--- feature_3 <= 4.05
    |   |   |   |   |   |   |--- feature_3 <= 3.15
    |   |   |   |   |   |   |   |--- feature_0 <= 431.73
    |   |   |   |   |   |   |   |   |--- feature_3 <= 1.40
    |   |   |   |   |   |   |   |   |   |--- value: [51.80]
    |   |   |   |   |   |   |   |   |--- feature_3 >  1.40
    |   |   |   |   |   |   |   |   |   |--- value: [50.40]
    |   |   |   |   |   |   |   |--- feature_0 >  431.73
    |   |   |   |   |   |   |   |   |--- value: [53.90]
    |   |   |   |   |   |   |--- feature_3 >  3.15
    |   |   |   |   |   |   |   |--- feature_3 <= 3.70
    |   |   |   |   |   |   |   |   |--- feature_0 <= 378.85
    |   |   |   |   |   |   |   |   |   |--- value: [61.90]
    |   |   |   |   |   |   |   |   |--- feature_0 >  378.85
    |   |   |   |   |   |   |   |   |   |--- value: [58.80]
    |   |   |   |   |   |   |   |--- feature_3 >  3.70
    |   |   |   |   |   |   |   |   |--- value: [55.00]
    |   |   |   |   |   |--- feature_3 >  4.05
    |   |   |   |   |   |   |--- feature_0 <= 441.64
    |   |   |   |   |   |   |   |--- feature_3 <= 5.05
    |   |   |   |   |   |   |   |   |--- feature_2 <= 24.98
    |   |   |   |   |   |   |   |   |   |--- value: [45.20]
    |   |   |   |   |   |   |   |   |--- feature_2 >  24.98
    |   |   |   |   |   |   |   |   |   |--- value: [44.70]
    |   |   |   |   |   |   |   |--- feature_3 >  5.05
    |   |   |   |   |   |   |   |   |--- feature_3 <= 10.55
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 6.15
    |   |   |   |   |   |   |   |   |   |   |--- value: [52.20]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  6.15
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 <= 7.50
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [49.30]
    |   |   |   |   |   |   |   |   |   |   |--- feature_1 >  7.50
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [49.80]
    |   |   |   |   |   |   |   |   |--- feature_3 >  10.55
    |   |   |   |   |   |   |   |   |   |--- value: [46.80]
    |   |   |   |   |   |   |--- feature_0 >  441.64
    |   |   |   |   |   |   |   |--- value: [57.10]
    |   |   |   |   |--- feature_0 >  645.41
    |   |   |   |   |   |--- value: [36.70]
    |   |--- feature_3 >  11.70
    |   |   |--- feature_0 <= 331.73
    |   |   |   |--- feature_3 <= 39.70
    |   |   |   |   |--- feature_2 <= 24.98
    |   |   |   |   |   |--- feature_1 <= 5.50
    |   |   |   |   |   |   |--- feature_1 <= 0.50
    |   |   |   |   |   |   |   |--- value: [42.90]
    |   |   |   |   |   |   |--- feature_1 >  0.50
    |   |   |   |   |   |   |   |--- feature_3 <= 12.95
    |   |   |   |   |   |   |   |   |--- value: [35.10]
    |   |   |   |   |   |   |   |--- feature_3 >  12.95
    |   |   |   |   |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |   |   |   |   |--- value: [26.90]
    |   |   |   |   |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |   |   |   |   |--- value: [29.30]
    |   |   |   |   |   |--- feature_1 >  5.50
    |   |   |   |   |   |   |--- feature_3 <= 13.65
    |   |   |   |   |   |   |   |--- feature_3 <= 13.40
    |   |   |   |   |   |   |   |   |--- value: [48.10]
    |   |   |   |   |   |   |   |--- feature_3 >  13.40
    |   |   |   |   |   |   |   |   |--- value: [47.40]
    |   |   |   |   |   |   |--- feature_3 >  13.65
    |   |   |   |   |   |   |   |--- feature_0 <= 128.86
    |   |   |   |   |   |   |   |   |--- value: [48.20]
    |   |   |   |   |   |   |   |--- feature_0 >  128.86
    |   |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 18.35
    |   |   |   |   |   |   |   |   |   |   |--- value: [41.40]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  18.35
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 27.25
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [37.20]
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  27.25
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [36.30]
    |   |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 33.15
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 263.61
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  263.61
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [43.40]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  33.15
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [40.90]
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |--- feature_2 >  24.98
    |   |   |   |   |   |--- feature_3 <= 30.75
    |   |   |   |   |   |   |--- feature_3 <= 16.55
    |   |   |   |   |   |   |   |--- feature_2 <= 24.98
    |   |   |   |   |   |   |   |   |--- feature_3 <= 14.00
    |   |   |   |   |   |   |   |   |   |--- value: [44.50]
    |   |   |   |   |   |   |   |   |--- feature_3 >  14.00
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 14.85
    |   |   |   |   |   |   |   |   |   |   |--- value: [53.30]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  14.85
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 16.05
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  16.05
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |--- feature_2 >  24.98
    |   |   |   |   |   |   |   |   |--- value: [55.10]
    |   |   |   |   |   |   |--- feature_3 >  16.55
    |   |   |   |   |   |   |   |--- feature_1 <= 5.50
    |   |   |   |   |   |   |   |   |--- value: [59.60]
    |   |   |   |   |   |   |   |--- feature_1 >  5.50
    |   |   |   |   |   |   |   |   |--- feature_0 <= 113.36
    |   |   |   |   |   |   |   |   |   |--- value: [46.60]
    |   |   |   |   |   |   |   |   |--- feature_0 >  113.36
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 23.60
    |   |   |   |   |   |   |   |   |   |   |--- value: [51.00]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  23.60
    |   |   |   |   |   |   |   |   |   |   |--- value: [53.30]
    |   |   |   |   |   |--- feature_3 >  30.75
    |   |   |   |   |   |   |--- feature_3 <= 32.60
    |   |   |   |   |   |   |   |--- feature_0 <= 123.41
    |   |   |   |   |   |   |   |   |--- value: [37.90]
    |   |   |   |   |   |   |   |--- feature_0 >  123.41
    |   |   |   |   |   |   |   |   |--- feature_1 <= 8.50
    |   |   |   |   |   |   |   |   |   |--- value: [40.20]
    |   |   |   |   |   |   |   |   |--- feature_1 >  8.50
    |   |   |   |   |   |   |   |   |   |--- value: [39.70]
    |   |   |   |   |   |   |--- feature_3 >  32.60
    |   |   |   |   |   |   |   |--- feature_3 <= 35.70
    |   |   |   |   |   |   |   |   |--- feature_0 <= 145.74
    |   |   |   |   |   |   |   |   |   |--- value: [47.10]
    |   |   |   |   |   |   |   |   |--- feature_0 >  145.74
    |   |   |   |   |   |   |   |   |   |--- value: [48.20]
    |   |   |   |   |   |   |   |--- feature_3 >  35.70
    |   |   |   |   |   |   |   |   |--- value: [41.00]
    |   |   |   |--- feature_3 >  39.70
    |   |   |   |   |--- feature_1 <= 7.50
    |   |   |   |   |   |--- feature_0 <= 146.30
    |   |   |   |   |   |   |--- feature_0 <= 91.29
    |   |   |   |   |   |   |   |--- value: [42.70]
    |   |   |   |   |   |   |--- feature_0 >  91.29
    |   |   |   |   |   |   |   |--- value: [60.70]
    |   |   |   |   |   |--- feature_0 >  146.30
    |   |   |   |   |   |   |--- value: [41.00]
    |   |   |   |   |--- feature_1 >  7.50
    |   |   |   |   |   |--- feature_3 <= 41.15
    |   |   |   |   |   |   |--- value: [67.70]
    |   |   |   |   |   |--- feature_3 >  41.15
    |   |   |   |   |   |   |--- value: [63.30]
    |   |   |--- feature_0 >  331.73
    |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |--- feature_0 <= 428.39
    |   |   |   |   |   |--- feature_1 <= 5.50
    |   |   |   |   |   |   |--- value: [24.50]
    |   |   |   |   |   |--- feature_1 >  5.50
    |   |   |   |   |   |   |--- value: [30.50]
    |   |   |   |   |--- feature_0 >  428.39
    |   |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |   |--- feature_3 <= 19.15
    |   |   |   |   |   |   |   |--- feature_3 <= 17.15
    |   |   |   |   |   |   |   |   |--- value: [34.60]
    |   |   |   |   |   |   |   |--- feature_3 >  17.15
    |   |   |   |   |   |   |   |   |--- value: [34.00]
    |   |   |   |   |   |   |--- feature_3 >  19.15
    |   |   |   |   |   |   |   |--- value: [32.90]
    |   |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |   |--- value: [34.70]
    |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |--- feature_0 <= 345.04
    |   |   |   |   |   |--- feature_0 <= 338.42
    |   |   |   |   |   |   |--- feature_3 <= 33.50
    |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |--- value: [36.50]
    |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |--- value: [38.10]
    |   |   |   |   |   |   |--- feature_3 >  33.50
    |   |   |   |   |   |   |   |--- value: [32.40]
    |   |   |   |   |   |--- feature_0 >  338.42
    |   |   |   |   |   |   |--- value: [26.50]
    |   |   |   |   |--- feature_0 >  345.04
    |   |   |   |   |   |--- feature_3 <= 22.50
    |   |   |   |   |   |   |--- feature_2 <= 24.99
    |   |   |   |   |   |   |   |--- feature_3 <= 19.00
    |   |   |   |   |   |   |   |   |--- feature_0 <= 741.46
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 13.45
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 13.25
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  13.25
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [35.10]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  13.45
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 <= 24.98
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 >  24.98
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |--- feature_0 >  741.46
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 13.10
    |   |   |   |   |   |   |   |   |   |   |--- value: [37.00]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  13.10
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 15.65
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  15.65
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [38.10]
    |   |   |   |   |   |   |   |--- feature_3 >  19.00
    |   |   |   |   |   |   |   |   |--- feature_3 <= 20.90
    |   |   |   |   |   |   |   |   |   |--- feature_2 <= 24.98
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [48.10]
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [47.00]
    |   |   |   |   |   |   |   |   |   |--- feature_2 >  24.98
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 677.16
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [39.60]
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  677.16
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [46.40]
    |   |   |   |   |   |   |   |   |--- feature_3 >  20.90
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 21.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 525.17
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [42.50]
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  525.17
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [42.20]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  21.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [42.00]
    |   |   |   |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 2
    |   |   |   |   |   |   |--- feature_2 >  24.99
    |   |   |   |   |   |   |   |--- feature_3 <= 13.20
    |   |   |   |   |   |   |   |   |--- feature_3 <= 12.80
    |   |   |   |   |   |   |   |   |   |--- value: [42.00]
    |   |   |   |   |   |   |   |   |--- feature_3 >  12.80
    |   |   |   |   |   |   |   |   |   |--- value: [45.90]
    |   |   |   |   |   |   |   |--- feature_3 >  13.20
    |   |   |   |   |   |   |   |   |--- value: [51.05]
    |   |   |   |   |   |--- feature_3 >  22.50
    |   |   |   |   |   |   |--- feature_0 <= 787.05
    |   |   |   |   |   |   |   |--- feature_0 <= 743.85
    |   |   |   |   |   |   |   |   |--- feature_0 <= 713.10
    |   |   |   |   |   |   |   |   |   |--- feature_1 <= 9.50
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 617.58
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 9
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  617.58
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |   |   |   |   |   |--- feature_1 >  9.50
    |   |   |   |   |   |   |   |   |   |   |--- value: [48.50]
    |   |   |   |   |   |   |   |   |--- feature_0 >  713.10
    |   |   |   |   |   |   |   |   |   |--- value: [55.30]
    |   |   |   |   |   |   |   |--- feature_0 >  743.85
    |   |   |   |   |   |   |   |   |--- value: [25.00]
    |   |   |   |   |   |   |--- feature_0 >  787.05
    |   |   |   |   |   |   |   |--- value: [62.90]
    |--- feature_0 >  826.83
    |   |--- feature_2 <= 24.98
    |   |   |--- feature_0 <= 4007.27
    |   |   |   |--- feature_3 <= 30.00
    |   |   |   |   |--- feature_2 <= 24.93
    |   |   |   |   |   |--- feature_3 <= 16.35
    |   |   |   |   |   |   |--- value: [29.30]
    |   |   |   |   |   |--- feature_3 >  16.35
    |   |   |   |   |   |   |--- value: [45.10]
    |   |   |   |   |--- feature_2 >  24.93
    |   |   |   |   |   |--- feature_3 <= 4.40
    |   |   |   |   |   |   |--- feature_0 <= 1505.02
    |   |   |   |   |   |   |   |--- feature_3 <= 1.90
    |   |   |   |   |   |   |   |   |--- value: [27.00]
    |   |   |   |   |   |   |   |--- feature_3 >  1.90
    |   |   |   |   |   |   |   |   |--- value: [25.60]
    |   |   |   |   |   |   |--- feature_0 >  1505.02
    |   |   |   |   |   |   |   |--- feature_3 <= 3.95
    |   |   |   |   |   |   |   |   |--- feature_3 <= 2.30
    |   |   |   |   |   |   |   |   |   |--- value: [33.40]
    |   |   |   |   |   |   |   |   |--- feature_3 >  2.30
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 3.25
    |   |   |   |   |   |   |   |   |   |   |--- value: [31.10]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  3.25
    |   |   |   |   |   |   |   |   |   |   |--- value: [31.70]
    |   |   |   |   |   |   |   |--- feature_3 >  3.95
    |   |   |   |   |   |   |   |   |--- feature_0 <= 2163.81
    |   |   |   |   |   |   |   |   |   |--- value: [29.55]
    |   |   |   |   |   |   |   |   |--- feature_0 >  2163.81
    |   |   |   |   |   |   |   |   |   |--- value: [28.60]
    |   |   |   |   |   |--- feature_3 >  4.40
    |   |   |   |   |   |   |--- feature_0 <= 2274.72
    |   |   |   |   |   |   |   |--- feature_2 <= 24.97
    |   |   |   |   |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 6.90
    |   |   |   |   |   |   |   |   |   |   |--- value: [31.30]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  6.90
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 2161.20
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 7
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  2161.20
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 7
    |   |   |   |   |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |   |   |   |   |--- feature_0 <= 1714.91
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 11.70
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [28.80]
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  11.70
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |   |--- feature_0 >  1714.91
    |   |   |   |   |   |   |   |   |   |   |--- value: [26.75]
    |   |   |   |   |   |   |   |--- feature_2 >  24.97
    |   |   |   |   |   |   |   |   |--- feature_1 <= 3.50
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 23.70
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 <= 18.00
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 3
    |   |   |   |   |   |   |   |   |   |   |--- feature_3 >  18.00
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [20.90]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  23.70
    |   |   |   |   |   |   |   |   |   |   |--- value: [27.00]
    |   |   |   |   |   |   |   |   |--- feature_1 >  3.50
    |   |   |   |   |   |   |   |   |   |--- value: [30.70]
    |   |   |   |   |   |   |--- feature_0 >  2274.72
    |   |   |   |   |   |   |   |--- feature_3 <= 24.15
    |   |   |   |   |   |   |   |   |--- feature_2 <= 24.94
    |   |   |   |   |   |   |   |   |   |--- value: [29.30]
    |   |   |   |   |   |   |   |   |--- feature_2 >  24.94
    |   |   |   |   |   |   |   |   |   |--- feature_2 <= 24.96
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 3513.06
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 4
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  3513.06
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [25.30]
    |   |   |   |   |   |   |   |   |   |--- feature_2 >  24.96
    |   |   |   |   |   |   |   |   |   |   |--- value: [25.70]
    |   |   |   |   |   |   |   |--- feature_3 >  24.15
    |   |   |   |   |   |   |   |   |--- value: [17.70]
    |   |   |   |--- feature_3 >  30.00
    |   |   |   |   |--- feature_3 <= 34.55
    |   |   |   |   |   |--- feature_3 <= 31.55
    |   |   |   |   |   |   |--- feature_1 <= 0.50
    |   |   |   |   |   |   |   |--- feature_0 <= 1210.57
    |   |   |   |   |   |   |   |   |--- value: [19.00]
    |   |   |   |   |   |   |   |--- feature_0 >  1210.57
    |   |   |   |   |   |   |   |   |--- value: [18.30]
    |   |   |   |   |   |   |--- feature_1 >  0.50
    |   |   |   |   |   |   |   |--- feature_1 <= 2.00
    |   |   |   |   |   |   |   |   |--- value: [20.70]
    |   |   |   |   |   |   |   |--- feature_1 >  2.00
    |   |   |   |   |   |   |   |   |--- value: [21.50]
    |   |   |   |   |   |--- feature_3 >  31.55
    |   |   |   |   |   |   |--- feature_2 <= 24.95
    |   |   |   |   |   |   |   |--- value: [16.10]
    |   |   |   |   |   |   |--- feature_2 >  24.95
    |   |   |   |   |   |   |   |--- feature_0 <= 1158.12
    |   |   |   |   |   |   |   |   |--- value: [12.80]
    |   |   |   |   |   |   |   |--- feature_0 >  1158.12
    |   |   |   |   |   |   |   |   |--- value: [13.80]
    |   |   |   |   |--- feature_3 >  34.55
    |   |   |   |   |   |--- value: [31.90]
    |   |   |--- feature_0 >  4007.27
    |   |   |   |--- feature_3 <= 32.05
    |   |   |   |   |--- feature_0 <= 5954.16
    |   |   |   |   |   |--- feature_3 <= 25.05
    |   |   |   |   |   |   |--- feature_3 <= 20.60
    |   |   |   |   |   |   |   |--- feature_3 <= 16.65
    |   |   |   |   |   |   |   |   |--- feature_3 <= 16.40
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 16.25
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 <= 4070.66
    |   |   |   |   |   |   |   |   |   |   |   |--- value: [11.60]
    |   |   |   |   |   |   |   |   |   |   |--- feature_0 >  4070.66
    |   |   |   |   |   |   |   |   |   |   |   |--- truncated branch of depth 6
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  16.25
    |   |   |   |   |   |   |   |   |   |   |--- value: [20.50]
    |   |   |   |   |   |   |   |   |--- feature_3 >  16.40
    |   |   |   |   |   |   |   |   |   |--- value: [12.80]
    |   |   |   |   |   |   |   |--- feature_3 >  16.65
    |   |   |   |   |   |   |   |   |--- feature_2 <= 24.94
    |   |   |   |   |   |   |   |   |   |--- value: [18.80]
    |   |   |   |   |   |   |   |   |--- feature_2 >  24.94
    |   |   |   |   |   |   |   |   |   |--- feature_3 <= 16.85
    |   |   |   |   |   |   |   |   |   |   |--- value: [18.20]
    |   |   |   |   |   |   |   |   |   |--- feature_3 >  16.85
    |   |   |   |   |   |   |   |   |   |   |--- value: [18.30]
    |   |   |   |   |   |   |--- feature_3 >  20.60
    |   |   |   |   |   |   |   |--- value: [13.40]
    |   |   |   |   |   |--- feature_3 >  25.05
    |   |   |   |   |   |   |--- feature_0 <= 4479.81
    |   |   |   |   |   |   |   |--- feature_2 <= 24.95
    |   |   |   |   |   |   |   |   |--- value: [15.50]
    |   |   |   |   |   |   |   |--- feature_2 >  24.95
    |   |   |   |   |   |   |   |   |--- value: [17.40]
    |   |   |   |   |   |   |--- feature_0 >  4479.81
    |   |   |   |   |   |   |   |--- feature_0 <= 5015.86
    |   |   |   |   |   |   |   |   |--- feature_1 <= 0.50
    |   |   |   |   |   |   |   |   |   |--- value: [22.10]
    |   |   |   |   |   |   |   |   |--- feature_1 >  0.50
    |   |   |   |   |   |   |   |   |   |--- value: [22.60]
    |   |   |   |   |   |   |   |--- feature_0 >  5015.86
    |   |   |   |   |   |   |   |   |--- value: [17.40]
    |   |   |   |   |--- feature_0 >  5954.16
    |   |   |   |   |   |--- feature_2 <= 24.95
    |   |   |   |   |   |   |--- value: [12.20]
    |   |   |   |   |   |--- feature_2 >  24.95
    |   |   |   |   |   |   |--- value: [11.20]
    |   |   |   |--- feature_3 >  32.05
    |   |   |   |   |--- value: [24.70]
    |   |--- feature_2 >  24.98
    |   |   |--- feature_3 <= 12.20
    |   |   |   |--- feature_0 <= 1404.22
    |   |   |   |   |--- feature_3 <= 9.05
    |   |   |   |   |   |--- value: [38.50]
    |   |   |   |   |--- feature_3 >  9.05
    |   |   |   |   |   |--- feature_3 <= 9.55
    |   |   |   |   |   |   |--- value: [42.75]
    |   |   |   |   |   |--- feature_3 >  9.55
    |   |   |   |   |   |   |--- value: [43.50]
    |   |   |   |--- feature_0 >  1404.22
    |   |   |   |   |--- feature_2 <= 24.99
    |   |   |   |   |   |--- value: [48.00]
    |   |   |   |   |--- feature_2 >  24.99
    |   |   |   |   |   |--- value: [46.60]
    |   |   |--- feature_3 >  12.20
    |   |   |   |--- feature_3 <= 26.10
    |   |   |   |   |--- feature_0 <= 1154.64
    |   |   |   |   |   |--- feature_3 <= 12.80
    |   |   |   |   |   |   |--- value: [34.10]
    |   |   |   |   |   |--- feature_3 >  12.80
    |   |   |   |   |   |   |--- feature_2 <= 24.99
    |   |   |   |   |   |   |   |--- value: [37.70]
    |   |   |   |   |   |   |--- feature_2 >  24.99
    |   |   |   |   |   |   |   |--- value: [36.70]
    |   |   |   |   |--- feature_0 >  1154.64
    |   |   |   |   |   |--- feature_0 <= 1496.49
    |   |   |   |   |   |   |--- feature_0 <= 1200.70
    |   |   |   |   |   |   |   |--- value: [32.20]
    |   |   |   |   |   |   |--- feature_0 >  1200.70
    |   |   |   |   |   |   |   |--- value: [30.60]
    |   |   |   |   |   |--- feature_0 >  1496.49
    |   |   |   |   |   |   |--- feature_3 <= 16.60
    |   |   |   |   |   |   |   |--- value: [27.30]
    |   |   |   |   |   |   |--- feature_3 >  16.60
    |   |   |   |   |   |   |   |--- value: [31.10]
    |   |   |   |--- feature_3 >  26.10
    |   |   |   |   |--- value: [41.20]
    
    MSE: 112.88895111111113
    RMSE: 10.624921228466173
    R2: 0.33760032194067



![png](output_12_1.png)



```python
#集合算法--随机森林
from sklearn.ensemble import RandomForestRegressor

# 训练
model = RandomForestRegressor().fit(X_train, y_train)
print (model, "\n")


predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)
rmse = np.sqrt(mse)
print("RMSE:", rmse)
r2 = r2_score(y_test, predictions)
print("R2:", r2)

plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title('Daily Bike Share Predictions')

z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()

```

    /opt/tljh/user/lib/python3.6/site-packages/sklearn/ensemble/forest.py:245: FutureWarning: The default value of n_estimators will change from 10 in version 0.20 to 100 in 0.22.
      "10 in version 0.20 to 100 in 0.22.", FutureWarning)


    RandomForestRegressor(bootstrap=True, criterion='mse', max_depth=None,
                          max_features='auto', max_leaf_nodes=None,
                          min_impurity_decrease=0.0, min_impurity_split=None,
                          min_samples_leaf=1, min_samples_split=2,
                          min_weight_fraction_leaf=0.0, n_estimators=10,
                          n_jobs=None, oob_score=False, random_state=None,
                          verbose=0, warm_start=False) 
    
    MSE: 64.82537852089342
    RMSE: 8.051420900741274
    R2: 0.6196234490650024



![png](output_13_2.png)



```python
#GradientBoostingRegressor集合算法
from sklearn.ensemble import GradientBoostingRegressor

# Fit a lasso model on the training set
model = GradientBoostingRegressor().fit(X_train, y_train)
print (model, "\n")

# Evaluate the model using the test data
predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)
rmse = np.sqrt(mse)
print("RMSE:", rmse)
r2 = r2_score(y_test, predictions)
print("R2:", r2)

# Plot predicted vs actual
plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title("Price Per Unit of Building Predictions")
# overlay the regression line
z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()

```

    GradientBoostingRegressor(alpha=0.9, criterion='friedman_mse', init=None,
                              learning_rate=0.1, loss='ls', max_depth=3,
                              max_features=None, max_leaf_nodes=None,
                              min_impurity_decrease=0.0, min_impurity_split=None,
                              min_samples_leaf=1, min_samples_split=2,
                              min_weight_fraction_leaf=0.0, n_estimators=100,
                              n_iter_no_change=None, presort='auto',
                              random_state=None, subsample=1.0, tol=0.0001,
                              validation_fraction=0.1, verbose=0, warm_start=False) 
    
    MSE: 52.14477526483675
    RMSE: 7.221133932066123
    R2: 0.6940295572955828



![png](output_14_1.png)



```python
#优化超参数 GradientBoostingRegressor估计器
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer, r2_score

# Use a Gradient Boosting algorithm
alg = GradientBoostingRegressor()

# Try these hyperparameter values
params = {
 'learning_rate': [0.1, 0.5, 1.0],
 'n_estimators' : [50, 100, 150]
 }

# Find the best hyperparameter combination to optimize the R2 metric
score = make_scorer(r2_score)
gridsearch = GridSearchCV(alg, params, scoring=score, cv=3, return_train_score=True)
gridsearch.fit(X_train, y_train)
print("Best parameter combination:", gridsearch.best_params_, "\n")

# Get the best model
model=gridsearch.best_estimator_
print(model, "\n")

# Evaluate the model using the test data
predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)
rmse = np.sqrt(mse)
print("RMSE:", rmse)
r2 = r2_score(y_test, predictions)
print("R2:", r2)

# Plot predicted vs actual
plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title("Price Per Unit of Building Predictions")
# overlay the regression line
z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()
```

    Best parameter combination: {'learning_rate': 0.1, 'n_estimators': 100} 
    
    GradientBoostingRegressor(alpha=0.9, criterion='friedman_mse', init=None,
                              learning_rate=0.1, loss='ls', max_depth=3,
                              max_features=None, max_leaf_nodes=None,
                              min_impurity_decrease=0.0, min_impurity_split=None,
                              min_samples_leaf=1, min_samples_split=2,
                              min_weight_fraction_leaf=0.0, n_estimators=100,
                              n_iter_no_change=None, presort='auto',
                              random_state=None, subsample=1.0, tol=0.0001,
                              validation_fraction=0.1, verbose=0, warm_start=False) 
    
    MSE: 52.2897345261092
    RMSE: 7.2311641197050145
    R2: 0.6931789783234735


    /opt/tljh/user/lib/python3.6/site-packages/sklearn/model_selection/_search.py:814: DeprecationWarning: The default of the `iid` parameter will change from True to False in version 0.22 and will be removed in 0.24. This will change numeric results when test-set sizes are unequal.
      DeprecationWarning)



![png](output_15_2.png)



```python
# Train the model
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LinearRegression
import numpy as np

# Define preprocessing for numeric columns (scale them)，进行数据预处理
numeric_features = [1,2,3]
numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())])

# Define preprocessing for categorical features (encode them)
categorical_features = [0]
categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))])

# Combine preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)])
# Create preprocessing and training pipeline
pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                           ('regressor', GradientBoostingRegressor())])

# fit the pipeline to train a linear regression model on the training set
model = pipeline.fit(X_train, (y_train))
print (model, "\n")

# Get predictions
predictions = model.predict(X_test)

# Display metrics
mse = mean_squared_error(y_test, predictions)
print("MSE:", mse)
rmse = np.sqrt(mse)
print("RMSE:", rmse)
r2 = r2_score(y_test, predictions)
print("R2:", r2)

# Plot predicted vs actual
plt.scatter(y_test, predictions)
plt.xlabel('Actual Labels')
plt.ylabel('Predicted Labels')
plt.title('Daily Bike Share Predictions - Preprocessed')
z = np.polyfit(y_test, predictions, 1)
p = np.poly1d(z)
plt.plot(y_test,p(y_test), color='magenta')
plt.show()
```

    Pipeline(memory=None,
             steps=[('preprocessor',
                     ColumnTransformer(n_jobs=None, remainder='drop',
                                       sparse_threshold=0.3,
                                       transformer_weights=None,
                                       transformers=[('num',
                                                      Pipeline(memory=None,
                                                               steps=[('scaler',
                                                                       StandardScaler(copy=True,
                                                                                      with_mean=True,
                                                                                      with_std=True))],
                                                               verbose=False),
                                                      [1, 2, 3]),
                                                     ('cat',
                                                      Pipeline(memory=None,
                                                               steps=[('onehot',
                                                                       OneHotEncoder(categorical_fe...
                                               init=None, learning_rate=0.1,
                                               loss='ls', max_depth=3,
                                               max_features=None,
                                               max_leaf_nodes=None,
                                               min_impurity_decrease=0.0,
                                               min_impurity_split=None,
                                               min_samples_leaf=1,
                                               min_samples_split=2,
                                               min_weight_fraction_leaf=0.0,
                                               n_estimators=100,
                                               n_iter_no_change=None,
                                               presort='auto', random_state=None,
                                               subsample=1.0, tol=0.0001,
                                               validation_fraction=0.1, verbose=0,
                                               warm_start=False))],
             verbose=False) 
    
    MSE: 62.40663377016798
    RMSE: 7.899786944606037
    R2: 0.6338159429133268



![png](output_16_1.png)



```python
#保存文件
import joblib

# 将模型保存为一个pickle文件
filename = './model/building-price.pkl'
joblib.dump(model, filename)
```




    ['./model/building-price.pkl']




```python

```
